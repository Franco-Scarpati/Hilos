namespace SistemaImpresion
{
    //El dato que viaja del productor (usuario) al consumidor (impresora).
    class TrabajoImpresion
    {
        public int Numero;
        public string Usuario;
        public string Documento;

        public override string ToString()
        {
            return $"#{Numero} \"{Documento}\" (de {Usuario})";
        }
    }
}
