using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SistemaImpresion")]
[assembly: AssemblyDescription("Sistema de impresion concurrente: Singleton + Monitor + Strategy + Productor-Consumidor")]
[assembly: AssemblyProduct("SistemaImpresion")]
[assembly: AssemblyCopyright("Franco Scarpati")]
[assembly: ComVisible(false)]
[assembly: Guid("7eab9d26-f67a-45e1-aa93-0772fbce821d")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
