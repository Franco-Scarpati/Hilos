namespace SistemaImpresion
{
    //ConcreteStrategy: notifica por SMS.
    class NotificadorSms : INotificador
    {
        public void Notificar(string usuario, string documento)
        {
            Program.Log($"   [SMS]      {usuario}: tu documento \"{documento}\" ya se imprimio");
        }
    }
}
