namespace SistemaImpresion
{
    //ConcreteStrategy: notifica por Email.
    class NotificadorEmail : INotificador
    {
        public void Notificar(string usuario, string documento)
        {
            Program.Log($"   [Email]    {usuario}: tu documento \"{documento}\" ya se imprimio");
        }
    }
}
