namespace SistemaImpresion
{
    //Strategy: la forma de notificar. La impresora depende de esta interfaz
    //y NO de las clases concretas, asi no sabe el algoritmo de cada medio.
    interface INotificador
    {
        void Notificar(string usuario, string documento);
    }
}
