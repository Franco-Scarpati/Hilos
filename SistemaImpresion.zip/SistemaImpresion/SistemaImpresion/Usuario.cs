using System;
using System.Threading;

namespace SistemaImpresion
{
    //Productor: envia trabajos a la impresora (el recurso compartido Singleton).
    class Usuario
    {
        private static readonly string[] Documentos =
            { "Informe.pdf", "Factura.docx", "Planilla.xlsx", "Contrato.pdf",
              "Apunte.pdf", "Recibo.pdf", "Presupuesto.xlsx" };
        private static int ultimoNumero = 0;

        private readonly string nombre;
        private readonly int minTrabajos;
        private readonly int maxTrabajos;
        private readonly Random rnd;

        public int Enviados { get; private set; }

        public Usuario(string nombre, int minTrabajos, int maxTrabajos, int semilla)
        {
            this.nombre = nombre;
            this.minTrabajos = minTrabajos;
            this.maxTrabajos = maxTrabajos;
            rnd = new Random(semilla);   //una semilla distinta por usuario
        }

        public void Ejecutar()
        {
            //Cada usuario envia un numero ALEATORIO de trabajos.
            int cantidad = rnd.Next(minTrabajos, maxTrabajos + 1);
            Program.Log($"{nombre} va a enviar {cantidad} trabajos");

            for (int i = 0; i < cantidad; i++)
            {
                Thread.Sleep(rnd.Next(100, 400));   //tiempo aleatorio entre envios
                TrabajoImpresion t = new TrabajoImpresion
                {
                    Numero = Interlocked.Increment(ref ultimoNumero),
                    Usuario = nombre,
                    Documento = Documentos[rnd.Next(Documentos.Length)]
                };
                //Si la cola esta llena, EnviarTrabajo lo hace esperar (control de velocidad).
                Impresora.Instancia.EnviarTrabajo(t);
                Enviados++;
            }
            Program.Log($"{nombre} termino de enviar sus {Enviados} trabajos");
        }
    }
}
