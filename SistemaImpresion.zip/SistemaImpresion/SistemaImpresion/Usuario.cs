using System;
using System.Threading;

namespace SistemaImpresion
{
    //Productor: envia trabajos a la impresora (el recurso compartido Singleton).
    class Usuario
    {
        private static readonly string[] Documentos =
            { "Informe.pdf", "Factura.docx", "Planilla.xlsx", "Contrato.pdf",
              "Apunte.pdf", "Recibo.pdf", "Presupuesto.xlsx" };
        private static int ultimoNumero = 0;

        private readonly string nombre;
        private readonly int cantidad;
        private readonly Random rnd;

        public Usuario(string nombre, int cantidad, int semilla)
        {
            this.nombre = nombre;
            this.cantidad = cantidad;
            rnd = new Random(semilla);   //una semilla distinta por usuario
        }

        public void Ejecutar()
        {
            for (int i = 0; i < cantidad; i++)
            {
                Thread.Sleep(rnd.Next(100, 400));   //el usuario arma el documento
                TrabajoImpresion t = new TrabajoImpresion
                {
                    Numero = Interlocked.Increment(ref ultimoNumero),
                    Usuario = nombre,
                    Documento = Documentos[rnd.Next(Documentos.Length)]
                };
                //Si la cola esta llena, EnviarTrabajo lo hace esperar (control de velocidad).
                Impresora.Instancia.EnviarTrabajo(t);
            }
            Program.Log($"{nombre} termino de enviar sus trabajos");
        }
    }
}
