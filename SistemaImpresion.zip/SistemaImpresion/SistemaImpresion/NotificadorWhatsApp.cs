namespace SistemaImpresion
{
    //ConcreteStrategy: notifica por WhatsApp.
    class NotificadorWhatsApp : INotificador
    {
        public void Notificar(string usuario, string documento)
        {
            Program.Log($"   [WhatsApp] {usuario}: tu documento \"{documento}\" ya se imprimio");
        }
    }
}
