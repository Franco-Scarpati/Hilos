using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace SistemaImpresion
{
    class Program
    {
        private static readonly Stopwatch reloj = Stopwatch.StartNew();
        private static readonly object candadoConsola = new object();

        public static void Log(string mensaje)
        {
            lock (candadoConsola)
                Console.WriteLine($"{reloj.Elapsed.TotalSeconds,5:0.00}s  {mensaje}");
        }

        static void Main()
        {
            const int TRABAJOS_POR_USUARIO = 4;

            //SINGLETON: siempre la misma instancia de impresora.
            Impresora impresora = Impresora.Instancia;

            //STRATEGY: le inyectamos los 3 medios. La impresora no conoce estas clases.
            impresora.Configurar(3, new List<INotificador>
            {
                new NotificadorSms(),
                new NotificadorWhatsApp(),
                new NotificadorEmail()
            });

            //Productores: los usuarios que mandan a imprimir.
            Usuario[] usuarios =
            {
                new Usuario("Ana  ", TRABAJOS_POR_USUARIO, 1),
                new Usuario("Beto ", TRABAJOS_POR_USUARIO, 2),
                new Usuario("Carla", TRABAJOS_POR_USUARIO, 3)
            };

            //Consumidor: la impresora corre en su propio hilo.
            Thread hiloImpresora = new Thread(impresora.Ejecutar);
            hiloImpresora.Start();

            //Arrancamos los usuarios.
            List<Thread> hilosUsuarios = new List<Thread>();
            foreach (Usuario u in usuarios) hilosUsuarios.Add(new Thread(u.Ejecutar));
            hilosUsuarios.ForEach(h => h.Start());

            hilosUsuarios.ForEach(h => h.Join());   //esperamos a los usuarios...
            impresora.Cerrar();                     //...y cerramos la impresora
            hiloImpresora.Join();

            int esperado = usuarios.Length * TRABAJOS_POR_USUARIO;
            Console.WriteLine();
            Console.WriteLine($"Trabajos: {esperado} | Impresos: {impresora.Impresos} | " +
                              (impresora.Impresos == esperado ? "OK" : "ERROR: se perdieron trabajos"));
        }
    }
}
