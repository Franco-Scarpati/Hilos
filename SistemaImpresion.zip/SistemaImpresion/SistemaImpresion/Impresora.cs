using System.Collections.Generic;
using System.Threading;

namespace SistemaImpresion
{
    //Impresora: recurso compartido.
    //  - SINGLETON: una sola instancia en toda la aplicacion.
    //  - MONITOR: sincroniza el acceso a la cola de trabajos.
    //  - CONSUMIDOR: procesa los trabajos y notifica (Strategy).
    class Impresora
    {
        //================== SINGLETON ==================
        private static Impresora instancia;
        private static readonly object candadoInstancia = new object();

        //Doble verificacion: thread-safe aunque varios hilos pidan la instancia.
        public static Impresora Instancia
        {
            get
            {
                if (instancia == null)
                {
                    lock (candadoInstancia)
                    {
                        if (instancia == null)
                            instancia = new Impresora();
                    }
                }
                return instancia;
            }
        }

        private Impresora() { }   //constructor privado: nadie la crea de afuera

        //================== ESTADO ==================
        private readonly Queue<TrabajoImpresion> cola = new Queue<TrabajoImpresion>();
        private readonly object candado = new object();
        private int capacidad = 5;
        private bool cerrada = false;
        private List<INotificador> notificadores = new List<INotificador>();

        public int Impresos { get; private set; }

        //Main inyecta la capacidad y los notificadores: la impresora NO
        //conoce las clases concretas (SMS/WhatsApp/Email), solo la interfaz.
        public void Configurar(int capacidad, List<INotificador> notificadores)
        {
            this.capacidad = capacidad;
            this.notificadores = notificadores;
        }

        //================== PRODUCTOR: lo llama un USUARIO ==================
        //Control de velocidad: si la cola esta llena, el usuario espera
        //hasta que la impresora libere un lugar y lo despierte (Pulse).
        public void EnviarTrabajo(TrabajoImpresion t)
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                while (cola.Count == capacidad)
                {
                    Program.Log($"{t.Usuario} espera: cola llena " + Ocupacion());
                    Monitor.Wait(candado);          //libera el lock y duerme
                }

                cola.Enqueue(t);
                Program.Log($"{t.Usuario} envia {t}  " + Ocupacion());
                Monitor.PulseAll(candado);          //aviso: hay trabajo / hay lugar
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        //================== CONSUMIDOR: uso interno de la impresora ==================
        //Devuelve null cuando esta cerrada y vacia (no hay mas trabajo).
        public TrabajoImpresion ObtenerSiguienteTrabajo()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                while (cola.Count == 0 && !cerrada)
                    Monitor.Wait(candado);

                if (cola.Count == 0)                //vacia y cerrada
                    return null;

                TrabajoImpresion t = cola.Dequeue();
                Monitor.PulseAll(candado);          //aviso: hay lugar en la cola
                return t;
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        //Bucle del consumidor: corre en su propio hilo.
        public void Ejecutar()
        {
            TrabajoImpresion t;
            while ((t = ObtenerSiguienteTrabajo()) != null)
            {
                Imprimir(t);        //la impresion va FUERA del lock
                Notificar(t);       //notifica por los 3 medios (Strategy)
                Impresos++;
            }
            Program.Log("Impresora: no hay mas trabajos, se apaga");
        }

        //Simula la impresion. No toca la cola, por eso va fuera del lock.
        private void Imprimir(TrabajoImpresion t)
        {
            Program.Log($"Imprimiendo {t} ...");
            Thread.Sleep(600);
            Program.Log($"Listo {t}");
        }

        //La impresora recorre sus notificadores sin saber cual es cada uno.
        private void Notificar(TrabajoImpresion t)
        {
            foreach (INotificador n in notificadores)
                n.Notificar(t.Usuario, t.Documento);
        }

        //La llama Main cuando todos los usuarios terminaron de enviar.
        public void Cerrar()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);
                cerrada = true;
                Monitor.PulseAll(candado);          //despierta a la impresora si dormia
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        //Se llama siempre con el lock tomado.
        private string Ocupacion()
        {
            return "[" + new string('#', cola.Count)
                       + new string('.', capacidad - cola.Count) + "]";
        }
    }
}
